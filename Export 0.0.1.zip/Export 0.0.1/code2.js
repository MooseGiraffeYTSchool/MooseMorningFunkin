gdjs.charactersCode = {};

gdjs.charactersCode.conditionTrue_0 = {val:false};
gdjs.charactersCode.condition0IsTrue_0 = {val:false};


gdjs.charactersCode.eventsList0 = function(runtimeScene) {

};

gdjs.charactersCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.charactersCode.eventsList0(runtimeScene);
return;

}

gdjs['charactersCode'] = gdjs.charactersCode;
