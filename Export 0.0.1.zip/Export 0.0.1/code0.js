gdjs.PlayStateCode = {};
gdjs.PlayStateCode.GDiconsObjects1= [];
gdjs.PlayStateCode.GDiconsObjects2= [];
gdjs.PlayStateCode.GDiconsObjects3= [];
gdjs.PlayStateCode.GDiconsObjects4= [];
gdjs.PlayStateCode.GDNoteDOWNtrickyObjects1= [];
gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2= [];
gdjs.PlayStateCode.GDNoteDOWNtrickyObjects3= [];
gdjs.PlayStateCode.GDNoteDOWNtrickyObjects4= [];
gdjs.PlayStateCode.GDNoteDOWNObjects1= [];
gdjs.PlayStateCode.GDNoteDOWNObjects2= [];
gdjs.PlayStateCode.GDNoteDOWNObjects3= [];
gdjs.PlayStateCode.GDNoteDOWNObjects4= [];
gdjs.PlayStateCode.GDNoteLEFTtrickyObjects1= [];
gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2= [];
gdjs.PlayStateCode.GDNoteLEFTtrickyObjects3= [];
gdjs.PlayStateCode.GDNoteLEFTtrickyObjects4= [];
gdjs.PlayStateCode.GDNoteLEFTObjects1= [];
gdjs.PlayStateCode.GDNoteLEFTObjects2= [];
gdjs.PlayStateCode.GDNoteLEFTObjects3= [];
gdjs.PlayStateCode.GDNoteLEFTObjects4= [];
gdjs.PlayStateCode.GDNoteRIGHTDeathObjects1= [];
gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2= [];
gdjs.PlayStateCode.GDNoteRIGHTDeathObjects3= [];
gdjs.PlayStateCode.GDNoteRIGHTDeathObjects4= [];
gdjs.PlayStateCode.GDNoteRIGHTObjects1= [];
gdjs.PlayStateCode.GDNoteRIGHTObjects2= [];
gdjs.PlayStateCode.GDNoteRIGHTObjects3= [];
gdjs.PlayStateCode.GDNoteRIGHTObjects4= [];
gdjs.PlayStateCode.GDNoteUPDeathObjects1= [];
gdjs.PlayStateCode.GDNoteUPDeathObjects2= [];
gdjs.PlayStateCode.GDNoteUPDeathObjects3= [];
gdjs.PlayStateCode.GDNoteUPDeathObjects4= [];
gdjs.PlayStateCode.GDNoteUPObjects1= [];
gdjs.PlayStateCode.GDNoteUPObjects2= [];
gdjs.PlayStateCode.GDNoteUPObjects3= [];
gdjs.PlayStateCode.GDNoteUPObjects4= [];
gdjs.PlayStateCode.GDbeat4Objects1= [];
gdjs.PlayStateCode.GDbeat4Objects2= [];
gdjs.PlayStateCode.GDbeat4Objects3= [];
gdjs.PlayStateCode.GDbeat4Objects4= [];
gdjs.PlayStateCode.GDbeat3Objects1= [];
gdjs.PlayStateCode.GDbeat3Objects2= [];
gdjs.PlayStateCode.GDbeat3Objects3= [];
gdjs.PlayStateCode.GDbeat3Objects4= [];
gdjs.PlayStateCode.GDbeat2Objects1= [];
gdjs.PlayStateCode.GDbeat2Objects2= [];
gdjs.PlayStateCode.GDbeat2Objects3= [];
gdjs.PlayStateCode.GDbeat2Objects4= [];
gdjs.PlayStateCode.GDStageObjects1= [];
gdjs.PlayStateCode.GDStageObjects2= [];
gdjs.PlayStateCode.GDStageObjects3= [];
gdjs.PlayStateCode.GDStageObjects4= [];
gdjs.PlayStateCode.GDbeat1Objects1= [];
gdjs.PlayStateCode.GDbeat1Objects2= [];
gdjs.PlayStateCode.GDbeat1Objects3= [];
gdjs.PlayStateCode.GDbeat1Objects4= [];
gdjs.PlayStateCode.GDC_95PlaytochartObjects1= [];
gdjs.PlayStateCode.GDC_95PlaytochartObjects2= [];
gdjs.PlayStateCode.GDC_95PlaytochartObjects3= [];
gdjs.PlayStateCode.GDC_95PlaytochartObjects4= [];
gdjs.PlayStateCode.GDdaNotePlacerObjects1= [];
gdjs.PlayStateCode.GDdaNotePlacerObjects2= [];
gdjs.PlayStateCode.GDdaNotePlacerObjects3= [];
gdjs.PlayStateCode.GDdaNotePlacerObjects4= [];
gdjs.PlayStateCode.GDdaRankinObjects1= [];
gdjs.PlayStateCode.GDdaRankinObjects2= [];
gdjs.PlayStateCode.GDdaRankinObjects3= [];
gdjs.PlayStateCode.GDdaRankinObjects4= [];
gdjs.PlayStateCode.GDslidersObjects1= [];
gdjs.PlayStateCode.GDslidersObjects2= [];
gdjs.PlayStateCode.GDslidersObjects3= [];
gdjs.PlayStateCode.GDslidersObjects4= [];
gdjs.PlayStateCode.GDtutorialObjects1= [];
gdjs.PlayStateCode.GDtutorialObjects2= [];
gdjs.PlayStateCode.GDtutorialObjects3= [];
gdjs.PlayStateCode.GDtutorialObjects4= [];
gdjs.PlayStateCode.GDdaRankinDisplayerObjects1= [];
gdjs.PlayStateCode.GDdaRankinDisplayerObjects2= [];
gdjs.PlayStateCode.GDdaRankinDisplayerObjects3= [];
gdjs.PlayStateCode.GDdaRankinDisplayerObjects4= [];
gdjs.PlayStateCode.GDNewObjectObjects1= [];
gdjs.PlayStateCode.GDNewObjectObjects2= [];
gdjs.PlayStateCode.GDNewObjectObjects3= [];
gdjs.PlayStateCode.GDNewObjectObjects4= [];
gdjs.PlayStateCode.GDCharactersObjects1= [];
gdjs.PlayStateCode.GDCharactersObjects2= [];
gdjs.PlayStateCode.GDCharactersObjects3= [];
gdjs.PlayStateCode.GDCharactersObjects4= [];
gdjs.PlayStateCode.GDFrontStageObjects1= [];
gdjs.PlayStateCode.GDFrontStageObjects2= [];
gdjs.PlayStateCode.GDFrontStageObjects3= [];
gdjs.PlayStateCode.GDFrontStageObjects4= [];
gdjs.PlayStateCode.GDNewObject2Objects1= [];
gdjs.PlayStateCode.GDNewObject2Objects2= [];
gdjs.PlayStateCode.GDNewObject2Objects3= [];
gdjs.PlayStateCode.GDNewObject2Objects4= [];
gdjs.PlayStateCode.GDadditionalstagestuffObjects1= [];
gdjs.PlayStateCode.GDadditionalstagestuffObjects2= [];
gdjs.PlayStateCode.GDadditionalstagestuffObjects3= [];
gdjs.PlayStateCode.GDadditionalstagestuffObjects4= [];
gdjs.PlayStateCode.GDmissObjects1= [];
gdjs.PlayStateCode.GDmissObjects2= [];
gdjs.PlayStateCode.GDmissObjects3= [];
gdjs.PlayStateCode.GDmissObjects4= [];
gdjs.PlayStateCode.GDscoreactualObjects1= [];
gdjs.PlayStateCode.GDscoreactualObjects2= [];
gdjs.PlayStateCode.GDscoreactualObjects3= [];
gdjs.PlayStateCode.GDscoreactualObjects4= [];
gdjs.PlayStateCode.GDscoreObjects1= [];
gdjs.PlayStateCode.GDscoreObjects2= [];
gdjs.PlayStateCode.GDscoreObjects3= [];
gdjs.PlayStateCode.GDscoreObjects4= [];
gdjs.PlayStateCode.GDmissesObjects1= [];
gdjs.PlayStateCode.GDmissesObjects2= [];
gdjs.PlayStateCode.GDmissesObjects3= [];
gdjs.PlayStateCode.GDmissesObjects4= [];

gdjs.PlayStateCode.conditionTrue_0 = {val:false};
gdjs.PlayStateCode.condition0IsTrue_0 = {val:false};
gdjs.PlayStateCode.condition1IsTrue_0 = {val:false};
gdjs.PlayStateCode.condition2IsTrue_0 = {val:false};
gdjs.PlayStateCode.condition3IsTrue_0 = {val:false};
gdjs.PlayStateCode.condition4IsTrue_0 = {val:false};
gdjs.PlayStateCode.conditionTrue_1 = {val:false};
gdjs.PlayStateCode.condition0IsTrue_1 = {val:false};
gdjs.PlayStateCode.condition1IsTrue_1 = {val:false};
gdjs.PlayStateCode.condition2IsTrue_1 = {val:false};
gdjs.PlayStateCode.condition3IsTrue_1 = {val:false};
gdjs.PlayStateCode.condition4IsTrue_1 = {val:false};


gdjs.PlayStateCode.eventsList0 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}{for(var i = 0, len = gdjs.PlayStateCode.GDdaNotePlacerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaNotePlacerObjects2[i].setPosition(52,-(574));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects2[i].setAngle(0);
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.PlayStateCode.GDdaNotePlacerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaNotePlacerObjects2[i].setPosition(52,574);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects2[i].setAngle(180);
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("C_Playtochart"), gdjs.PlayStateCode.GDC_95PlaytochartObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDC_95PlaytochartObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDC_95PlaytochartObjects2[i].setPosition(400,300);
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("C_Playtochart"), gdjs.PlayStateCode.GDC_95PlaytochartObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects2);
gdjs.copyArray(runtimeScene.getObjects("beat1"), gdjs.PlayStateCode.GDbeat1Objects2);
gdjs.copyArray(runtimeScene.getObjects("beat2"), gdjs.PlayStateCode.GDbeat2Objects2);
gdjs.copyArray(runtimeScene.getObjects("beat3"), gdjs.PlayStateCode.GDbeat3Objects2);
gdjs.copyArray(runtimeScene.getObjects("beat4"), gdjs.PlayStateCode.GDbeat4Objects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.PlayStateCode.GDC_95PlaytochartObjects2.length !== 0 ? gdjs.PlayStateCode.GDC_95PlaytochartObjects2[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.PlayStateCode.GDbeat4Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat4Objects2[i].setY(31);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDbeat3Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat3Objects2[i].setY(31);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDbeat2Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat2Objects2[i].setY(31);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDbeat1Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat1Objects2[i].setY(31);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteLEFTObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteLEFTObjects2[i].setX((( gdjs.PlayStateCode.GDbeat1Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat1Objects2[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteDOWNObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteDOWNObjects2[i].setX((( gdjs.PlayStateCode.GDbeat2Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat2Objects2[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteUPObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteUPObjects2[i].setX((( gdjs.PlayStateCode.GDbeat3Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat3Objects2[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteRIGHTObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].setX((( gdjs.PlayStateCode.GDbeat4Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat4Objects2[0].getPointX("")));
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("C_Playtochart"), gdjs.PlayStateCode.GDC_95PlaytochartObjects1);
gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects1);
gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects1);
gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects1);
gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects1);
gdjs.copyArray(runtimeScene.getObjects("beat1"), gdjs.PlayStateCode.GDbeat1Objects1);
gdjs.copyArray(runtimeScene.getObjects("beat2"), gdjs.PlayStateCode.GDbeat2Objects1);
gdjs.copyArray(runtimeScene.getObjects("beat3"), gdjs.PlayStateCode.GDbeat3Objects1);
gdjs.copyArray(runtimeScene.getObjects("beat4"), gdjs.PlayStateCode.GDbeat4Objects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.PlayStateCode.GDC_95PlaytochartObjects1.length !== 0 ? gdjs.PlayStateCode.GDC_95PlaytochartObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.PlayStateCode.GDbeat4Objects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat4Objects1[i].setY(527);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDbeat3Objects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat3Objects1[i].setY(527);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDbeat2Objects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat2Objects1[i].setY(527);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDbeat1Objects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat1Objects1[i].setY(527);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteLEFTObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteLEFTObjects1[i].setX((( gdjs.PlayStateCode.GDbeat1Objects1.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat1Objects1[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteDOWNObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteDOWNObjects1[i].setX((( gdjs.PlayStateCode.GDbeat2Objects1.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat2Objects1[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteUPObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteUPObjects1[i].setX((( gdjs.PlayStateCode.GDbeat3Objects1.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat3Objects1[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteRIGHTObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteRIGHTObjects1[i].setX((( gdjs.PlayStateCode.GDbeat4Objects1.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat4Objects1[0].getPointX("")));
}
}}

}


};gdjs.PlayStateCode.eventsList1 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition0IsTrue_0;
gdjs.PlayStateCode.condition0IsTrue_1.val = false;
gdjs.PlayStateCode.condition1IsTrue_1.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if( gdjs.PlayStateCode.condition0IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
gdjs.PlayStateCode.condition1IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "a"));
if( gdjs.PlayStateCode.condition1IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat1"), gdjs.PlayStateCode.GDbeat1Objects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDbeat1Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat1Objects2[i].setAnimation(0);
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition0IsTrue_0;
gdjs.PlayStateCode.condition0IsTrue_1.val = false;
gdjs.PlayStateCode.condition1IsTrue_1.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down"));
if( gdjs.PlayStateCode.condition0IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
gdjs.PlayStateCode.condition1IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "s"));
if( gdjs.PlayStateCode.condition1IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat2"), gdjs.PlayStateCode.GDbeat2Objects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDbeat2Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat2Objects2[i].setAnimation(0);
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition0IsTrue_0;
gdjs.PlayStateCode.condition0IsTrue_1.val = false;
gdjs.PlayStateCode.condition1IsTrue_1.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up"));
if( gdjs.PlayStateCode.condition0IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
gdjs.PlayStateCode.condition1IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "w"));
if( gdjs.PlayStateCode.condition1IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat3"), gdjs.PlayStateCode.GDbeat3Objects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDbeat3Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat3Objects2[i].setAnimation(0);
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition0IsTrue_0;
gdjs.PlayStateCode.condition0IsTrue_1.val = false;
gdjs.PlayStateCode.condition1IsTrue_1.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if( gdjs.PlayStateCode.condition0IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
gdjs.PlayStateCode.condition1IsTrue_1.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "d"));
if( gdjs.PlayStateCode.condition1IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat4"), gdjs.PlayStateCode.GDbeat4Objects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDbeat4Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat4Objects2[i].setAnimation(0);
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition0IsTrue_0;
gdjs.PlayStateCode.condition0IsTrue_1.val = false;
gdjs.PlayStateCode.condition1IsTrue_1.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if( gdjs.PlayStateCode.condition0IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
gdjs.PlayStateCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if( gdjs.PlayStateCode.condition1IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat1"), gdjs.PlayStateCode.GDbeat1Objects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDbeat1Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat1Objects2[i].setAnimation(1);
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition0IsTrue_0;
gdjs.PlayStateCode.condition0IsTrue_1.val = false;
gdjs.PlayStateCode.condition1IsTrue_1.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if( gdjs.PlayStateCode.condition0IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
gdjs.PlayStateCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if( gdjs.PlayStateCode.condition1IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat4"), gdjs.PlayStateCode.GDbeat4Objects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDbeat4Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat4Objects2[i].setAnimation(1);
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition0IsTrue_0;
gdjs.PlayStateCode.condition0IsTrue_1.val = false;
gdjs.PlayStateCode.condition1IsTrue_1.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if( gdjs.PlayStateCode.condition0IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
gdjs.PlayStateCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if( gdjs.PlayStateCode.condition1IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat3"), gdjs.PlayStateCode.GDbeat3Objects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDbeat3Objects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat3Objects2[i].setAnimation(1);
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition0IsTrue_0;
gdjs.PlayStateCode.condition0IsTrue_1.val = false;
gdjs.PlayStateCode.condition1IsTrue_1.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if( gdjs.PlayStateCode.condition0IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
gdjs.PlayStateCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if( gdjs.PlayStateCode.condition1IsTrue_1.val ) {
    gdjs.PlayStateCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat2"), gdjs.PlayStateCode.GDbeat2Objects1);
{for(var i = 0, len = gdjs.PlayStateCode.GDbeat2Objects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDbeat2Objects1[i].setAnimation(1);
}
}}

}


};gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects2Objects = Hashtable.newFrom({"NoteLEFT": gdjs.PlayStateCode.GDNoteLEFTObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTtrickyObjects2Objects = Hashtable.newFrom({"NoteLEFTtricky": gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects2Objects = Hashtable.newFrom({"NoteDOWN": gdjs.PlayStateCode.GDNoteDOWNObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects2Objects = Hashtable.newFrom({"NoteUP": gdjs.PlayStateCode.GDNoteUPObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects2Objects = Hashtable.newFrom({"NoteRIGHT": gdjs.PlayStateCode.GDNoteRIGHTObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTDeathObjects2Objects = Hashtable.newFrom({"NoteRIGHTDeath": gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPDeathObjects2Objects = Hashtable.newFrom({"NoteUPDeath": gdjs.PlayStateCode.GDNoteUPDeathObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNtrickyObjects2Objects = Hashtable.newFrom({"NoteDOWNtricky": gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects3Objects = Hashtable.newFrom({"NoteLEFT": gdjs.PlayStateCode.GDNoteLEFTObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTtrickyObjects3Objects = Hashtable.newFrom({"NoteLEFTtricky": gdjs.PlayStateCode.GDNoteLEFTtrickyObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects3Objects = Hashtable.newFrom({"NoteDOWN": gdjs.PlayStateCode.GDNoteDOWNObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects3Objects = Hashtable.newFrom({"NoteUP": gdjs.PlayStateCode.GDNoteUPObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects3Objects = Hashtable.newFrom({"NoteRIGHT": gdjs.PlayStateCode.GDNoteRIGHTObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects3Objects = Hashtable.newFrom({"NoteLEFT": gdjs.PlayStateCode.GDNoteLEFTObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects3Objects = Hashtable.newFrom({"NoteDOWN": gdjs.PlayStateCode.GDNoteDOWNObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects3Objects = Hashtable.newFrom({"NoteUP": gdjs.PlayStateCode.GDNoteUPObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects3Objects = Hashtable.newFrom({"NoteRIGHT": gdjs.PlayStateCode.GDNoteRIGHTObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects2Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects2});gdjs.PlayStateCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition3IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13933916);
}
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() + (100));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setY(gdjs.PlayStateCode.GDslidersObjects3[i].getY() - ((gdjs.PlayStateCode.GDslidersObjects3[i].getHeight()) * 3.75));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFTtricky"), gdjs.PlayStateCode.GDNoteLEFTtrickyObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTtrickyObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition3IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17183164);
}
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() + (100));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setY(gdjs.PlayStateCode.GDslidersObjects3[i].getY() - ((gdjs.PlayStateCode.GDslidersObjects3[i].getHeight()) * 3.75));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17759252);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() + (100));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setY(gdjs.PlayStateCode.GDslidersObjects3[i].getY() - ((gdjs.PlayStateCode.GDslidersObjects3[i].getHeight()) * 3.75));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17830676);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() + (100));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setY(gdjs.PlayStateCode.GDslidersObjects3[i].getY() - ((gdjs.PlayStateCode.GDslidersObjects3[i].getHeight()) * 3.75));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17838860);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() + (100));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setY(gdjs.PlayStateCode.GDslidersObjects3[i].getY() - ((gdjs.PlayStateCode.GDslidersObjects3[i].getHeight()) * 3.75));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "q");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17844772);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() / (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "q");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12010580);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() / (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "q");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12011372);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() / (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "q");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12012164);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() / (2));
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects3);
gdjs.PlayStateCode.GDslidersObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, (( gdjs.PlayStateCode.GDNoteLEFTObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteLEFTObjects3[0].getPointX("Center")), (( gdjs.PlayStateCode.GDNoteLEFTObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteLEFTObjects3[0].getPointY("Center")), "");
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects3);
gdjs.PlayStateCode.GDslidersObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, (( gdjs.PlayStateCode.GDNoteDOWNObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteDOWNObjects3[0].getPointX("Center")), (( gdjs.PlayStateCode.GDNoteDOWNObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteDOWNObjects3[0].getPointY("Center")), "");
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects3);
gdjs.PlayStateCode.GDslidersObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, (( gdjs.PlayStateCode.GDNoteUPObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteUPObjects3[0].getPointX("Center")), (( gdjs.PlayStateCode.GDNoteUPObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteUPObjects3[0].getPointY("Center")), "");
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects2);
gdjs.PlayStateCode.GDslidersObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects2Objects, (( gdjs.PlayStateCode.GDNoteRIGHTObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteRIGHTObjects2[0].getPointX("Center")), (( gdjs.PlayStateCode.GDNoteRIGHTObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteRIGHTObjects2[0].getPointY("Center")), "");
}}

}


};gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects3Objects = Hashtable.newFrom({"NoteLEFT": gdjs.PlayStateCode.GDNoteLEFTObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects3Objects = Hashtable.newFrom({"NoteDOWN": gdjs.PlayStateCode.GDNoteDOWNObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects3Objects = Hashtable.newFrom({"NoteUP": gdjs.PlayStateCode.GDNoteUPObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects3Objects = Hashtable.newFrom({"NoteRIGHT": gdjs.PlayStateCode.GDNoteRIGHTObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects3Objects = Hashtable.newFrom({"NoteLEFT": gdjs.PlayStateCode.GDNoteLEFTObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects3Objects = Hashtable.newFrom({"NoteDOWN": gdjs.PlayStateCode.GDNoteDOWNObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects3Objects = Hashtable.newFrom({"NoteUP": gdjs.PlayStateCode.GDNoteUPObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects3Objects = Hashtable.newFrom({"NoteRIGHT": gdjs.PlayStateCode.GDNoteRIGHTObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects3});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects2Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects2});gdjs.PlayStateCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12015580);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() * (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12016372);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() * (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12017188);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() * (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12017956);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() * (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "q");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12018748);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() / (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "q");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12019820);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() / (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "q");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12020996);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() / (2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects3);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects3);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
gdjs.PlayStateCode.condition3IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "q");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition1IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12022228);
}
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects3Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition2IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition3IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
}}
}
}
if (gdjs.PlayStateCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects3 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects3[i].setHeight(gdjs.PlayStateCode.GDslidersObjects3[i].getHeight() / (2));
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 1;
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects3);
gdjs.PlayStateCode.GDslidersObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, (( gdjs.PlayStateCode.GDNoteLEFTObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteLEFTObjects3[0].getPointX("Center")), (( gdjs.PlayStateCode.GDNoteLEFTObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteLEFTObjects3[0].getPointY("Center")), "");
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 2;
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects3);
gdjs.PlayStateCode.GDslidersObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, (( gdjs.PlayStateCode.GDNoteDOWNObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteDOWNObjects3[0].getPointX("Center")), (( gdjs.PlayStateCode.GDNoteDOWNObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteDOWNObjects3[0].getPointY("Center")), "");
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 3;
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects3);
gdjs.PlayStateCode.GDslidersObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects3Objects, (( gdjs.PlayStateCode.GDNoteUPObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteUPObjects3[0].getPointX("Center")), (( gdjs.PlayStateCode.GDNoteUPObjects3.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteUPObjects3[0].getPointY("Center")), "");
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) == 4;
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects2);
gdjs.PlayStateCode.GDslidersObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects2Objects, (( gdjs.PlayStateCode.GDNoteRIGHTObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteRIGHTObjects2[0].getPointX("Center")), (( gdjs.PlayStateCode.GDNoteRIGHTObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDNoteRIGHTObjects2[0].getPointY("Center")), "");
}}

}


};gdjs.PlayStateCode.eventsList4 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition0IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12029036);
}
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 0);
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 0);
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition0IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12029852);
}
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelPaused(runtimeScene, 0);
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "assets_songs_bopeebo_Voices.ogg", 0, false, 100, 1);
}}

}


};gdjs.PlayStateCode.eventsList5 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("C_Playtochart"), gdjs.PlayStateCode.GDC_95PlaytochartObjects2);
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDC_95PlaytochartObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDC_95PlaytochartObjects2[i].setY((( gdjs.PlayStateCode.GDdaNotePlacerObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDdaNotePlacerObjects2[0].getPointY("")));
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaNotePlacerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaNotePlacerObjects2[i].setY(gdjs.PlayStateCode.GDdaNotePlacerObjects2[i].getY() - (10));
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaNotePlacerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaNotePlacerObjects2[i].setY(gdjs.PlayStateCode.GDdaNotePlacerObjects2[i].getY() + (10));
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat1"), gdjs.PlayStateCode.GDbeat1Objects2);
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
gdjs.PlayStateCode.GDNoteLEFTObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects2Objects, (( gdjs.PlayStateCode.GDbeat1Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat1Objects2[0].getPointX("")), (( gdjs.PlayStateCode.GDdaNotePlacerObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDdaNotePlacerObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().getFromIndex(1).setNumber(1);
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num5");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat1"), gdjs.PlayStateCode.GDbeat1Objects2);
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTtrickyObjects2Objects, (( gdjs.PlayStateCode.GDbeat1Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat1Objects2[0].getPointX("")), (( gdjs.PlayStateCode.GDdaNotePlacerObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDdaNotePlacerObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().getFromIndex(1).setNumber(1);
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat2"), gdjs.PlayStateCode.GDbeat2Objects2);
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
gdjs.PlayStateCode.GDNoteDOWNObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects2Objects, (( gdjs.PlayStateCode.GDbeat2Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat2Objects2[0].getPointX("")), (( gdjs.PlayStateCode.GDdaNotePlacerObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDdaNotePlacerObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().getFromIndex(1).setNumber(2);
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num3");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat3"), gdjs.PlayStateCode.GDbeat3Objects2);
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
gdjs.PlayStateCode.GDNoteUPObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects2Objects, (( gdjs.PlayStateCode.GDbeat3Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat3Objects2[0].getPointX("")), (( gdjs.PlayStateCode.GDdaNotePlacerObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDdaNotePlacerObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().getFromIndex(1).setNumber(3);
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num4");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat4"), gdjs.PlayStateCode.GDbeat4Objects2);
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
gdjs.PlayStateCode.GDNoteRIGHTObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects2Objects, (( gdjs.PlayStateCode.GDbeat4Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat4Objects2[0].getPointX("")), (( gdjs.PlayStateCode.GDdaNotePlacerObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDdaNotePlacerObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().getFromIndex(1).setNumber(4);
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num8");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat4"), gdjs.PlayStateCode.GDbeat4Objects2);
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTDeathObjects2Objects, (( gdjs.PlayStateCode.GDbeat4Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat4Objects2[0].getPointX("")), (( gdjs.PlayStateCode.GDdaNotePlacerObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDdaNotePlacerObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().getFromIndex(1).setNumber(4);
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num7");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat3"), gdjs.PlayStateCode.GDbeat3Objects2);
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
gdjs.PlayStateCode.GDNoteUPDeathObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPDeathObjects2Objects, (( gdjs.PlayStateCode.GDbeat3Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat3Objects2[0].getPointX("")), (( gdjs.PlayStateCode.GDdaNotePlacerObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDdaNotePlacerObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().getFromIndex(1).setNumber(3);
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num6");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("beat2"), gdjs.PlayStateCode.GDbeat2Objects2);
gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);
gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNtrickyObjects2Objects, (( gdjs.PlayStateCode.GDbeat2Objects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDbeat2Objects2[0].getPointX("")), (( gdjs.PlayStateCode.GDdaNotePlacerObjects2.length === 0 ) ? 0 :gdjs.PlayStateCode.GDdaNotePlacerObjects2[0].getPointY("")), "");
}{runtimeScene.getVariables().getFromIndex(1).setNumber(2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDdaNotePlacerObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDdaNotePlacerObjects2[i].getY() <= 574 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDdaNotePlacerObjects2[k] = gdjs.PlayStateCode.GDdaNotePlacerObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDdaNotePlacerObjects2.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDdaNotePlacerObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDdaNotePlacerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaNotePlacerObjects2[i].setY(573);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("daNotePlacer"), gdjs.PlayStateCode.GDdaNotePlacerObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDdaNotePlacerObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDdaNotePlacerObjects2[i].getY() >= -(574) ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDdaNotePlacerObjects2[k] = gdjs.PlayStateCode.GDdaNotePlacerObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDdaNotePlacerObjects2.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDdaNotePlacerObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDdaNotePlacerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaNotePlacerObjects2[i].setY(-(573));
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.PlayStateCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.PlayStateCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "p");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.PlayStateCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.PlayStateCode.eventsList6 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.PlayStateCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.PlayStateCode.eventsList7 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num0");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("C_Playtochart"), gdjs.PlayStateCode.GDC_95PlaytochartObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDC_95PlaytochartObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDC_95PlaytochartObjects2[i].setY(800);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("C_Playtochart"), gdjs.PlayStateCode.GDC_95PlaytochartObjects1);
{for(var i = 0, len = gdjs.PlayStateCode.GDC_95PlaytochartObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDC_95PlaytochartObjects1[i].setY(300);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}}

}


};gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects2Objects = Hashtable.newFrom({"NoteLEFT": gdjs.PlayStateCode.GDNoteLEFTObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat1Objects2Objects = Hashtable.newFrom({"beat1": gdjs.PlayStateCode.GDbeat1Objects2});gdjs.PlayStateCode.eventsList8 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 1;
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.PlayStateCode.GDCharactersObjects2, gdjs.PlayStateCode.GDCharactersObjects3);

{for(var i = 0, len = gdjs.PlayStateCode.GDCharactersObjects3.length ;i < len;++i) {
    gdjs.PlayStateCode.GDCharactersObjects3[i].setAnimationName("majin left");
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "a"));
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).add(1);
}}

}


};gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTtrickyObjects2Objects = Hashtable.newFrom({"NoteLEFTtricky": gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat1Objects2Objects = Hashtable.newFrom({"beat1": gdjs.PlayStateCode.GDbeat1Objects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTDeathObjects2Objects = Hashtable.newFrom({"NoteRIGHTDeath": gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat4Objects2Objects = Hashtable.newFrom({"beat4": gdjs.PlayStateCode.GDbeat4Objects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects2Objects = Hashtable.newFrom({"NoteDOWN": gdjs.PlayStateCode.GDNoteDOWNObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat2Objects2Objects = Hashtable.newFrom({"beat2": gdjs.PlayStateCode.GDbeat2Objects2});gdjs.PlayStateCode.eventsList9 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 1;
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDCharactersObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDCharactersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDCharactersObjects2[i].setAnimationName("majin down");
}
}}

}


};gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects2Objects = Hashtable.newFrom({"NoteUP": gdjs.PlayStateCode.GDNoteUPObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat3Objects2Objects = Hashtable.newFrom({"beat3": gdjs.PlayStateCode.GDbeat3Objects2});gdjs.PlayStateCode.eventsList10 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 1;
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDCharactersObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDCharactersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDCharactersObjects2[i].setAnimationName("majin up");
}
}}

}


};gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects2Objects = Hashtable.newFrom({"NoteRIGHT": gdjs.PlayStateCode.GDNoteRIGHTObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat4Objects2Objects = Hashtable.newFrom({"beat4": gdjs.PlayStateCode.GDbeat4Objects2});gdjs.PlayStateCode.eventsList11 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) == 1;
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDCharactersObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDCharactersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDCharactersObjects2[i].setAnimationName("majin right");
}
}}

}


};gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects2Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat1Objects2Objects = Hashtable.newFrom({"beat1": gdjs.PlayStateCode.GDbeat1Objects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects2Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat2Objects2Objects = Hashtable.newFrom({"beat2": gdjs.PlayStateCode.GDbeat2Objects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects2Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat3Objects2Objects = Hashtable.newFrom({"beat3": gdjs.PlayStateCode.GDbeat3Objects2});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects1Objects = Hashtable.newFrom({"sliders": gdjs.PlayStateCode.GDslidersObjects1});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat4Objects1Objects = Hashtable.newFrom({"beat4": gdjs.PlayStateCode.GDbeat4Objects1});gdjs.PlayStateCode.eventsList12 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteDOWNtricky"), gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteLEFTtricky"), gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteRIGHTDeath"), gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteUPDeath"), gdjs.PlayStateCode.GDNoteUPDeathObjects2);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteDOWNObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteDOWNObjects2[i].setY(gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getY() - (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteUPDeathObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteUPDeathObjects2[i].setY(gdjs.PlayStateCode.GDNoteUPDeathObjects2[i].getY() - (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2[i].setY(gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2[i].getY() - (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2[i].setY(gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2[i].getY() - (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2[i].setY(gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2[i].getY() - (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteLEFTObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteLEFTObjects2[i].setY(gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getY() - (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteUPObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteUPObjects2[i].setY(gdjs.PlayStateCode.GDNoteUPObjects2[i].getY() - (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteRIGHTObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].setY(gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getY() - (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects2[i].setY(gdjs.PlayStateCode.GDslidersObjects2[i].getY() - (10));
}
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteDOWNtricky"), gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteLEFTtricky"), gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteRIGHTDeath"), gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects2);
gdjs.copyArray(runtimeScene.getObjects("NoteUPDeath"), gdjs.PlayStateCode.GDNoteUPDeathObjects2);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteDOWNObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteDOWNObjects2[i].setY(gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getY() + (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2[i].setY(gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2[i].getY() + (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2[i].setY(gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2[i].getY() + (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteUPDeathObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteUPDeathObjects2[i].setY(gdjs.PlayStateCode.GDNoteUPDeathObjects2[i].getY() + (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2[i].setY(gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2[i].getY() + (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteLEFTObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteLEFTObjects2[i].setY(gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getY() + (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteUPObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteUPObjects2[i].setY(gdjs.PlayStateCode.GDNoteUPObjects2[i].getY() + (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDNoteRIGHTObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].setY(gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getY() + (10));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects2[i].setY(gdjs.PlayStateCode.GDslidersObjects2[i].getY() + (10));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteLEFTObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getY() <= 569 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteLEFTObjects2[k] = gdjs.PlayStateCode.GDNoteLEFTObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteLEFTObjects2.length = k;}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDNoteLEFTObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteLEFTObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteLEFTObjects2[i].returnVariable(gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getVariables().getFromIndex(0)).add(0.5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteDOWNObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getY() <= 569 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteDOWNObjects2[k] = gdjs.PlayStateCode.GDNoteDOWNObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteDOWNObjects2.length = k;}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDNoteDOWNObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteDOWNObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteDOWNObjects2[i].returnVariable(gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getVariables().getFromIndex(0)).add(0.5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteUPObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteUPObjects2[i].getY() <= 569 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteUPObjects2[k] = gdjs.PlayStateCode.GDNoteUPObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteUPObjects2.length = k;}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDNoteUPObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteUPObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteUPObjects2[i].returnVariable(gdjs.PlayStateCode.GDNoteUPObjects2[i].getVariables().getFromIndex(0)).add(0.5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteRIGHTObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getY() <= 569 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteRIGHTObjects2[k] = gdjs.PlayStateCode.GDNoteRIGHTObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteRIGHTObjects2.length = k;}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDNoteRIGHTObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteRIGHTObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].returnVariable(gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getVariables().getFromIndex(0)).add(0.5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteLEFTObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getVariables().getFromIndex(0)) > 27 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteLEFTObjects2[k] = gdjs.PlayStateCode.GDNoteLEFTObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteLEFTObjects2.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteLEFTObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getVariables().getFromIndex(0)) < 29 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteLEFTObjects2[k] = gdjs.PlayStateCode.GDNoteLEFTObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteLEFTObjects2.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects2[i].setString("Note Rank: Sik!");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteLEFTObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getVariables().getFromIndex(0)) > 19 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteLEFTObjects2[k] = gdjs.PlayStateCode.GDNoteLEFTObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteLEFTObjects2.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteLEFTObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteLEFTObjects2[i].getVariables().getFromIndex(0)) < 25 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteLEFTObjects2[k] = gdjs.PlayStateCode.GDNoteLEFTObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteLEFTObjects2.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects2[i].setString("Note Rank: good");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteUPObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteUPObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteUPObjects2[i].getVariables().getFromIndex(0)) > 27 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteUPObjects2[k] = gdjs.PlayStateCode.GDNoteUPObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteUPObjects2.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteUPObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteUPObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteUPObjects2[i].getVariables().getFromIndex(0)) < 29 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteUPObjects2[k] = gdjs.PlayStateCode.GDNoteUPObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteUPObjects2.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects2[i].setString("Note Rank: Sik!");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteUPObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteUPObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteUPObjects2[i].getVariables().getFromIndex(0)) > 19 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteUPObjects2[k] = gdjs.PlayStateCode.GDNoteUPObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteUPObjects2.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteUPObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteUPObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteUPObjects2[i].getVariables().getFromIndex(0)) < 25 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteUPObjects2[k] = gdjs.PlayStateCode.GDNoteUPObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteUPObjects2.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects2[i].setString("Note Rank: good");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteDOWNObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getVariables().getFromIndex(0)) > 19 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteDOWNObjects2[k] = gdjs.PlayStateCode.GDNoteDOWNObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteDOWNObjects2.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteDOWNObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getVariables().getFromIndex(0)) < 25 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteDOWNObjects2[k] = gdjs.PlayStateCode.GDNoteDOWNObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteDOWNObjects2.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects2[i].setString("Note Rank: good");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteDOWNObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getVariables().getFromIndex(0)) > 27 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteDOWNObjects2[k] = gdjs.PlayStateCode.GDNoteDOWNObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteDOWNObjects2.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteDOWNObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteDOWNObjects2[i].getVariables().getFromIndex(0)) < 29 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteDOWNObjects2[k] = gdjs.PlayStateCode.GDNoteDOWNObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteDOWNObjects2.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects2[i].setString("Note Rank: Sik!");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteRIGHTObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getVariables().getFromIndex(0)) > 27 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteRIGHTObjects2[k] = gdjs.PlayStateCode.GDNoteRIGHTObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteRIGHTObjects2.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteRIGHTObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getVariables().getFromIndex(0)) < 29 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteRIGHTObjects2[k] = gdjs.PlayStateCode.GDNoteRIGHTObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteRIGHTObjects2.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects2[i].setString("Note Rank: Sik!");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteRIGHTObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getVariables().getFromIndex(0)) > 19 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteRIGHTObjects2[k] = gdjs.PlayStateCode.GDNoteRIGHTObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteRIGHTObjects2.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteRIGHTObjects2.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getVariableNumber(gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].getVariables().getFromIndex(0)) < 25 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteRIGHTObjects2[k] = gdjs.PlayStateCode.GDNoteRIGHTObjects2[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteRIGHTObjects2.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects2);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects2[i].setString("Note Rank: good");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects2);
gdjs.copyArray(runtimeScene.getObjects("beat1"), gdjs.PlayStateCode.GDbeat1Objects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTObjects2Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat1Objects2Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition2IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12052436);
}
}}
}
if (gdjs.PlayStateCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Characters"), gdjs.PlayStateCode.GDCharactersObjects2);
/* Reuse gdjs.PlayStateCode.GDNoteLEFTObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteLEFTObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteLEFTObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDCharactersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDCharactersObjects2[i].setAnimationName("bom left");
}
}{runtimeScene.getVariables().getFromIndex(4).add(100);
}
{ //Subevents
gdjs.PlayStateCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFTtricky"), gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2);
gdjs.copyArray(runtimeScene.getObjects("beat1"), gdjs.PlayStateCode.GDbeat1Objects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteLEFTtrickyObjects2Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat1Objects2Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition2IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17049188);
}
}}
}
if (gdjs.PlayStateCode.condition2IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Lose");
}{runtimeScene.getVariables().getFromIndex(4).sub(1000);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteRIGHTDeath"), gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2);
gdjs.copyArray(runtimeScene.getObjects("beat4"), gdjs.PlayStateCode.GDbeat4Objects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTDeathObjects2Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat4Objects2Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition2IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9308300);
}
}}
}
if (gdjs.PlayStateCode.condition2IsTrue_0.val) {
{/* Unknown object - skipped. */}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Lose");
}{runtimeScene.getVariables().getFromIndex(4).sub(1000);
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects2);
gdjs.copyArray(runtimeScene.getObjects("beat2"), gdjs.PlayStateCode.GDbeat2Objects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects2Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat2Objects2Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition2IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12053492);
}
}}
}
if (gdjs.PlayStateCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Characters"), gdjs.PlayStateCode.GDCharactersObjects2);
/* Reuse gdjs.PlayStateCode.GDNoteDOWNObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteDOWNObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteDOWNObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDCharactersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDCharactersObjects2[i].setAnimationName("bom down");
}
}{runtimeScene.getVariables().getFromIndex(4).add(100);
}
{ //Subevents
gdjs.PlayStateCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects2);
gdjs.copyArray(runtimeScene.getObjects("beat3"), gdjs.PlayStateCode.GDbeat3Objects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteUPObjects2Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat3Objects2Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition2IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12054548);
}
}}
}
if (gdjs.PlayStateCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Characters"), gdjs.PlayStateCode.GDCharactersObjects2);
/* Reuse gdjs.PlayStateCode.GDNoteUPObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteUPObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteUPObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDCharactersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDCharactersObjects2[i].setAnimationName("bom up");
}
}{runtimeScene.getVariables().getFromIndex(4).add(100);
}
{ //Subevents
gdjs.PlayStateCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects2);
gdjs.copyArray(runtimeScene.getObjects("beat4"), gdjs.PlayStateCode.GDbeat4Objects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteRIGHTObjects2Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat4Objects2Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition2IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12055604);
}
}}
}
if (gdjs.PlayStateCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Characters"), gdjs.PlayStateCode.GDCharactersObjects2);
/* Reuse gdjs.PlayStateCode.GDNoteRIGHTObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDNoteRIGHTObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDNoteRIGHTObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDCharactersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDCharactersObjects2[i].setAnimationName("bom right");
}
}{runtimeScene.getVariables().getFromIndex(4).add(100);
}
{ //Subevents
gdjs.PlayStateCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("beat1"), gdjs.PlayStateCode.GDbeat1Objects2);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects2Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat1Objects2Objects, false, runtimeScene, false);
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects2[i].setY(gdjs.PlayStateCode.GDslidersObjects2[i].getY() + (50));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects2[i].setHeight(gdjs.PlayStateCode.GDslidersObjects2[i].getHeight() - (80));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("beat2"), gdjs.PlayStateCode.GDbeat2Objects2);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects2Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat2Objects2Objects, false, runtimeScene, false);
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects2[i].setY(gdjs.PlayStateCode.GDslidersObjects2[i].getY() + (50));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects2[i].setHeight(gdjs.PlayStateCode.GDslidersObjects2[i].getHeight() - (80));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("beat3"), gdjs.PlayStateCode.GDbeat3Objects2);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects2);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "k");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects2Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat3Objects2Objects, false, runtimeScene, false);
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects2 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects2[i].setY(gdjs.PlayStateCode.GDslidersObjects2[i].getY() + (50));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects2.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects2[i].setWidth(gdjs.PlayStateCode.GDslidersObjects2[i].getWidth() - (80));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("beat4"), gdjs.PlayStateCode.GDbeat4Objects1);
gdjs.copyArray(runtimeScene.getObjects("sliders"), gdjs.PlayStateCode.GDslidersObjects1);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "l");
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDslidersObjects1Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat4Objects1Objects, false, runtimeScene, false);
}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
/* Reuse gdjs.PlayStateCode.GDslidersObjects1 */
{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects1[i].setY(gdjs.PlayStateCode.GDslidersObjects1[i].getY() + (50));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDslidersObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDslidersObjects1[i].setHeight(gdjs.PlayStateCode.GDslidersObjects1[i].getHeight() - (80));
}
}}

}


};gdjs.PlayStateCode.eventsList13 = function(runtimeScene) {

{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.PlayStateCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects1Objects = Hashtable.newFrom({"NoteDOWN": gdjs.PlayStateCode.GDNoteDOWNObjects1});gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat2Objects1Objects = Hashtable.newFrom({"beat2": gdjs.PlayStateCode.GDbeat2Objects1});gdjs.PlayStateCode.eventsList14 = function(runtimeScene) {

{


gdjs.PlayStateCode.eventsList0(runtimeScene);
}


{


gdjs.PlayStateCode.eventsList1(runtimeScene);
}


{


gdjs.PlayStateCode.eventsList6(runtimeScene);
}


{


gdjs.PlayStateCode.eventsList7(runtimeScene);
}


{


gdjs.PlayStateCode.eventsList13(runtimeScene);
}


{



}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("icons"), gdjs.PlayStateCode.GDiconsObjects1);
{for(var i = 0, len = gdjs.PlayStateCode.GDiconsObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDiconsObjects1[i].setAnimationName("bomb");
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "Bopeebo_Inst.ogg", true, 100, 1);
}}

}


{


gdjs.PlayStateCode.condition0IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "y");
}if (gdjs.PlayStateCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Characters"), gdjs.PlayStateCode.GDCharactersObjects1);
gdjs.copyArray(runtimeScene.getObjects("icons"), gdjs.PlayStateCode.GDiconsObjects1);
{for(var i = 0, len = gdjs.PlayStateCode.GDCharactersObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDCharactersObjects1[i].setAnimationName("majin idle");
}
}{runtimeScene.getVariables().getFromIndex(2).setNumber(1);
}{for(var i = 0, len = gdjs.PlayStateCode.GDiconsObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDiconsObjects1[i].setAnimationName("Majin");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteLEFT"), gdjs.PlayStateCode.GDNoteLEFTObjects1);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteLEFTObjects1.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteLEFTObjects1[i].getVariableNumber(gdjs.PlayStateCode.GDNoteLEFTObjects1[i].getVariables().getFromIndex(0)) > 19 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteLEFTObjects1[k] = gdjs.PlayStateCode.GDNoteLEFTObjects1[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteLEFTObjects1.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteLEFTObjects1.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteLEFTObjects1[i].getVariableNumber(gdjs.PlayStateCode.GDNoteLEFTObjects1[i].getVariables().getFromIndex(0)) < 15 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteLEFTObjects1[k] = gdjs.PlayStateCode.GDNoteLEFTObjects1[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteLEFTObjects1.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects1);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects1[i].setString("Note Rank: bad");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteRIGHT"), gdjs.PlayStateCode.GDNoteRIGHTObjects1);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteRIGHTObjects1.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteRIGHTObjects1[i].getVariableNumber(gdjs.PlayStateCode.GDNoteRIGHTObjects1[i].getVariables().getFromIndex(0)) > 19 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteRIGHTObjects1[k] = gdjs.PlayStateCode.GDNoteRIGHTObjects1[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteRIGHTObjects1.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteRIGHTObjects1.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteRIGHTObjects1[i].getVariableNumber(gdjs.PlayStateCode.GDNoteRIGHTObjects1[i].getVariables().getFromIndex(0)) < 15 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteRIGHTObjects1[k] = gdjs.PlayStateCode.GDNoteRIGHTObjects1[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteRIGHTObjects1.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects1);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects1[i].setString("Note Rank: bad");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteUP"), gdjs.PlayStateCode.GDNoteUPObjects1);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteUPObjects1.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteUPObjects1[i].getVariableNumber(gdjs.PlayStateCode.GDNoteUPObjects1[i].getVariables().getFromIndex(0)) < 15 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteUPObjects1[k] = gdjs.PlayStateCode.GDNoteUPObjects1[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteUPObjects1.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteUPObjects1.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteUPObjects1[i].getVariableNumber(gdjs.PlayStateCode.GDNoteUPObjects1[i].getVariables().getFromIndex(0)) > 19 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteUPObjects1[k] = gdjs.PlayStateCode.GDNoteUPObjects1[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteUPObjects1.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects1);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects1[i].setString("Note Rank: bad");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects1);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteDOWNObjects1.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteDOWNObjects1[i].getVariableNumber(gdjs.PlayStateCode.GDNoteDOWNObjects1[i].getVariables().getFromIndex(0)) > 19 ) {
        gdjs.PlayStateCode.condition0IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteDOWNObjects1[k] = gdjs.PlayStateCode.GDNoteDOWNObjects1[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteDOWNObjects1.length = k;}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlayStateCode.GDNoteDOWNObjects1.length;i<l;++i) {
    if ( gdjs.PlayStateCode.GDNoteDOWNObjects1[i].getVariableNumber(gdjs.PlayStateCode.GDNoteDOWNObjects1[i].getVariables().getFromIndex(0)) < 15 ) {
        gdjs.PlayStateCode.condition1IsTrue_0.val = true;
        gdjs.PlayStateCode.GDNoteDOWNObjects1[k] = gdjs.PlayStateCode.GDNoteDOWNObjects1[i];
        ++k;
    }
}
gdjs.PlayStateCode.GDNoteDOWNObjects1.length = k;}}
if (gdjs.PlayStateCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("daRankinDisplayer"), gdjs.PlayStateCode.GDdaRankinDisplayerObjects1);
{for(var i = 0, len = gdjs.PlayStateCode.GDdaRankinDisplayerObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDdaRankinDisplayerObjects1[i].setString("Note Rank: bad");
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("misses"), gdjs.PlayStateCode.GDmissesObjects1);
gdjs.copyArray(runtimeScene.getObjects("scoreactual"), gdjs.PlayStateCode.GDscoreactualObjects1);
{for(var i = 0, len = gdjs.PlayStateCode.GDmissesObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDmissesObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(3)));
}
}{for(var i = 0, len = gdjs.PlayStateCode.GDscoreactualObjects1.length ;i < len;++i) {
    gdjs.PlayStateCode.GDscoreactualObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(4)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoteDOWN"), gdjs.PlayStateCode.GDNoteDOWNObjects1);
gdjs.copyArray(runtimeScene.getObjects("beat2"), gdjs.PlayStateCode.GDbeat2Objects1);

gdjs.PlayStateCode.condition0IsTrue_0.val = false;
gdjs.PlayStateCode.condition1IsTrue_0.val = false;
gdjs.PlayStateCode.condition2IsTrue_0.val = false;
{
gdjs.PlayStateCode.condition0IsTrue_0.val = !(gdjs.evtTools.input.wasKeyReleased(runtimeScene, "s"));
}if ( gdjs.PlayStateCode.condition0IsTrue_0.val ) {
{
gdjs.PlayStateCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDNoteDOWNObjects1Objects, gdjs.PlayStateCode.mapOfGDgdjs_46PlayStateCode_46GDbeat2Objects1Objects, false, runtimeScene, false);
}if ( gdjs.PlayStateCode.condition1IsTrue_0.val ) {
{
{gdjs.PlayStateCode.conditionTrue_1 = gdjs.PlayStateCode.condition2IsTrue_0;
gdjs.PlayStateCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(14797468);
}
}}
}
if (gdjs.PlayStateCode.condition2IsTrue_0.val) {
}

}


};

gdjs.PlayStateCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PlayStateCode.GDiconsObjects1.length = 0;
gdjs.PlayStateCode.GDiconsObjects2.length = 0;
gdjs.PlayStateCode.GDiconsObjects3.length = 0;
gdjs.PlayStateCode.GDiconsObjects4.length = 0;
gdjs.PlayStateCode.GDNoteDOWNtrickyObjects1.length = 0;
gdjs.PlayStateCode.GDNoteDOWNtrickyObjects2.length = 0;
gdjs.PlayStateCode.GDNoteDOWNtrickyObjects3.length = 0;
gdjs.PlayStateCode.GDNoteDOWNtrickyObjects4.length = 0;
gdjs.PlayStateCode.GDNoteDOWNObjects1.length = 0;
gdjs.PlayStateCode.GDNoteDOWNObjects2.length = 0;
gdjs.PlayStateCode.GDNoteDOWNObjects3.length = 0;
gdjs.PlayStateCode.GDNoteDOWNObjects4.length = 0;
gdjs.PlayStateCode.GDNoteLEFTtrickyObjects1.length = 0;
gdjs.PlayStateCode.GDNoteLEFTtrickyObjects2.length = 0;
gdjs.PlayStateCode.GDNoteLEFTtrickyObjects3.length = 0;
gdjs.PlayStateCode.GDNoteLEFTtrickyObjects4.length = 0;
gdjs.PlayStateCode.GDNoteLEFTObjects1.length = 0;
gdjs.PlayStateCode.GDNoteLEFTObjects2.length = 0;
gdjs.PlayStateCode.GDNoteLEFTObjects3.length = 0;
gdjs.PlayStateCode.GDNoteLEFTObjects4.length = 0;
gdjs.PlayStateCode.GDNoteRIGHTDeathObjects1.length = 0;
gdjs.PlayStateCode.GDNoteRIGHTDeathObjects2.length = 0;
gdjs.PlayStateCode.GDNoteRIGHTDeathObjects3.length = 0;
gdjs.PlayStateCode.GDNoteRIGHTDeathObjects4.length = 0;
gdjs.PlayStateCode.GDNoteRIGHTObjects1.length = 0;
gdjs.PlayStateCode.GDNoteRIGHTObjects2.length = 0;
gdjs.PlayStateCode.GDNoteRIGHTObjects3.length = 0;
gdjs.PlayStateCode.GDNoteRIGHTObjects4.length = 0;
gdjs.PlayStateCode.GDNoteUPDeathObjects1.length = 0;
gdjs.PlayStateCode.GDNoteUPDeathObjects2.length = 0;
gdjs.PlayStateCode.GDNoteUPDeathObjects3.length = 0;
gdjs.PlayStateCode.GDNoteUPDeathObjects4.length = 0;
gdjs.PlayStateCode.GDNoteUPObjects1.length = 0;
gdjs.PlayStateCode.GDNoteUPObjects2.length = 0;
gdjs.PlayStateCode.GDNoteUPObjects3.length = 0;
gdjs.PlayStateCode.GDNoteUPObjects4.length = 0;
gdjs.PlayStateCode.GDbeat4Objects1.length = 0;
gdjs.PlayStateCode.GDbeat4Objects2.length = 0;
gdjs.PlayStateCode.GDbeat4Objects3.length = 0;
gdjs.PlayStateCode.GDbeat4Objects4.length = 0;
gdjs.PlayStateCode.GDbeat3Objects1.length = 0;
gdjs.PlayStateCode.GDbeat3Objects2.length = 0;
gdjs.PlayStateCode.GDbeat3Objects3.length = 0;
gdjs.PlayStateCode.GDbeat3Objects4.length = 0;
gdjs.PlayStateCode.GDbeat2Objects1.length = 0;
gdjs.PlayStateCode.GDbeat2Objects2.length = 0;
gdjs.PlayStateCode.GDbeat2Objects3.length = 0;
gdjs.PlayStateCode.GDbeat2Objects4.length = 0;
gdjs.PlayStateCode.GDStageObjects1.length = 0;
gdjs.PlayStateCode.GDStageObjects2.length = 0;
gdjs.PlayStateCode.GDStageObjects3.length = 0;
gdjs.PlayStateCode.GDStageObjects4.length = 0;
gdjs.PlayStateCode.GDbeat1Objects1.length = 0;
gdjs.PlayStateCode.GDbeat1Objects2.length = 0;
gdjs.PlayStateCode.GDbeat1Objects3.length = 0;
gdjs.PlayStateCode.GDbeat1Objects4.length = 0;
gdjs.PlayStateCode.GDC_95PlaytochartObjects1.length = 0;
gdjs.PlayStateCode.GDC_95PlaytochartObjects2.length = 0;
gdjs.PlayStateCode.GDC_95PlaytochartObjects3.length = 0;
gdjs.PlayStateCode.GDC_95PlaytochartObjects4.length = 0;
gdjs.PlayStateCode.GDdaNotePlacerObjects1.length = 0;
gdjs.PlayStateCode.GDdaNotePlacerObjects2.length = 0;
gdjs.PlayStateCode.GDdaNotePlacerObjects3.length = 0;
gdjs.PlayStateCode.GDdaNotePlacerObjects4.length = 0;
gdjs.PlayStateCode.GDdaRankinObjects1.length = 0;
gdjs.PlayStateCode.GDdaRankinObjects2.length = 0;
gdjs.PlayStateCode.GDdaRankinObjects3.length = 0;
gdjs.PlayStateCode.GDdaRankinObjects4.length = 0;
gdjs.PlayStateCode.GDslidersObjects1.length = 0;
gdjs.PlayStateCode.GDslidersObjects2.length = 0;
gdjs.PlayStateCode.GDslidersObjects3.length = 0;
gdjs.PlayStateCode.GDslidersObjects4.length = 0;
gdjs.PlayStateCode.GDtutorialObjects1.length = 0;
gdjs.PlayStateCode.GDtutorialObjects2.length = 0;
gdjs.PlayStateCode.GDtutorialObjects3.length = 0;
gdjs.PlayStateCode.GDtutorialObjects4.length = 0;
gdjs.PlayStateCode.GDdaRankinDisplayerObjects1.length = 0;
gdjs.PlayStateCode.GDdaRankinDisplayerObjects2.length = 0;
gdjs.PlayStateCode.GDdaRankinDisplayerObjects3.length = 0;
gdjs.PlayStateCode.GDdaRankinDisplayerObjects4.length = 0;
gdjs.PlayStateCode.GDNewObjectObjects1.length = 0;
gdjs.PlayStateCode.GDNewObjectObjects2.length = 0;
gdjs.PlayStateCode.GDNewObjectObjects3.length = 0;
gdjs.PlayStateCode.GDNewObjectObjects4.length = 0;
gdjs.PlayStateCode.GDCharactersObjects1.length = 0;
gdjs.PlayStateCode.GDCharactersObjects2.length = 0;
gdjs.PlayStateCode.GDCharactersObjects3.length = 0;
gdjs.PlayStateCode.GDCharactersObjects4.length = 0;
gdjs.PlayStateCode.GDFrontStageObjects1.length = 0;
gdjs.PlayStateCode.GDFrontStageObjects2.length = 0;
gdjs.PlayStateCode.GDFrontStageObjects3.length = 0;
gdjs.PlayStateCode.GDFrontStageObjects4.length = 0;
gdjs.PlayStateCode.GDNewObject2Objects1.length = 0;
gdjs.PlayStateCode.GDNewObject2Objects2.length = 0;
gdjs.PlayStateCode.GDNewObject2Objects3.length = 0;
gdjs.PlayStateCode.GDNewObject2Objects4.length = 0;
gdjs.PlayStateCode.GDadditionalstagestuffObjects1.length = 0;
gdjs.PlayStateCode.GDadditionalstagestuffObjects2.length = 0;
gdjs.PlayStateCode.GDadditionalstagestuffObjects3.length = 0;
gdjs.PlayStateCode.GDadditionalstagestuffObjects4.length = 0;
gdjs.PlayStateCode.GDmissObjects1.length = 0;
gdjs.PlayStateCode.GDmissObjects2.length = 0;
gdjs.PlayStateCode.GDmissObjects3.length = 0;
gdjs.PlayStateCode.GDmissObjects4.length = 0;
gdjs.PlayStateCode.GDscoreactualObjects1.length = 0;
gdjs.PlayStateCode.GDscoreactualObjects2.length = 0;
gdjs.PlayStateCode.GDscoreactualObjects3.length = 0;
gdjs.PlayStateCode.GDscoreactualObjects4.length = 0;
gdjs.PlayStateCode.GDscoreObjects1.length = 0;
gdjs.PlayStateCode.GDscoreObjects2.length = 0;
gdjs.PlayStateCode.GDscoreObjects3.length = 0;
gdjs.PlayStateCode.GDscoreObjects4.length = 0;
gdjs.PlayStateCode.GDmissesObjects1.length = 0;
gdjs.PlayStateCode.GDmissesObjects2.length = 0;
gdjs.PlayStateCode.GDmissesObjects3.length = 0;
gdjs.PlayStateCode.GDmissesObjects4.length = 0;

gdjs.PlayStateCode.eventsList14(runtimeScene);
return;

}

gdjs['PlayStateCode'] = gdjs.PlayStateCode;
